﻿using Cool_RPG.DialogueU;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool_RPG
{
    internal class NonPlayerCharacter : Character
    {
        public Dialogue dialogueTree {  get; set; }

    }
}
